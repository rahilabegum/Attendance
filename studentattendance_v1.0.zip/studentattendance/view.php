<?php
// This file is part of Moodle Exam Module - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Exam view page  redirect to registration page
 *
 * @package    mod_exam
 * @Author     Ramya
 * @copyright  2015 Royal Australian College of Surgeons.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once('../../config.php');
require_once(dirname(__FILE__).'/lib.php');
$id = optional_param('id' , 0, PARAM_INT);
$n  = optional_param('n' , 0, PARAM_INT);
global $DB;
if ($id) {
    $cm    = get_coursemodule_from_id('studentattendance' , $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course' , array('id' => $cm->course), '*', MUST_EXIST);
    $exam  = $DB->get_record('studentattendance' , array('id' => $cm->instance), '*', MUST_EXIST);
} else if ($n) {
    $exam  = $DB->get_record('studentattendance' , array('id' => $n) , '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $exam->course) , '*' , MUST_EXIST);
    $cm         = get_coursemodule_from_instance('studentattendance' , $exam->id , $course->id , false, MUST_EXIST);
} else {
    error('You must specify a course_module ID or an instance ID');
}
require_login($course, true, $cm);
$coursecontext = context_course::instance($exam->course);
$url      = new moodle_url('/mod/studentattendance/view.php?id='.$id);
$PAGE->set_url($url);
if (has_capability('mod/studentattendance:view' , $coursecontext)) {
    echo $OUTPUT->header();
    echo get_string('myattendance','studentattendance');
    $table                      = new html_table();
    $table->head                = array();
    $table->colclasses          = array();
    $table->attributes['class'] = 'studentattendence generaltable';
    $table->head[]              = 'Attendance name';
    $table->head[]              = 'Status';

    $table->head[]              = 'Remarks';
    $table->colclasses[]        = 'centeralign';
    $table->id                  = "myattendance";
    echo html_writer::start_tag('div', array(
        'class' => 'no-overflow'
    ));
    $sessionlists = $DB->get_records_sql("SELECT * FROM {studentattendance_details} sd inner join {studentattendance} sa on sd.attendanceid = sa.id and sd.userid = $USER->id");

    foreach($sessionlists as $skey => $sessionlist) {
        $points = '?';
        if($sessionlist->status == 'P') {
            $points = 2;
        }
        $row           = array();
        $row[]         = $sessionlist->name;
        $row[]         = $sessionlist->status;

        $row[]         = $sessionlist->remarks;
        $table->data[] = $row;
    }
    echo html_writer::table($table);
}
if(has_capability('mod/studentattendance:access' , $coursecontext)) {
    redirect(new moodle_url('/mod/studentattendance/take.php?id='.$id));
}