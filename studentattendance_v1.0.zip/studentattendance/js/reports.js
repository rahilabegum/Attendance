$(document).ready(function() {




	// $('#start').datetimepicker();
	 $('#start').timepicker({
		showLeadingZero: false,
		maxTime: {
			hour: 16, minute: 30
		}
	});
	$('#end').timepicker({
		showLeadingZero: false,
		maxTime: {
			hour: 16, minute: 30
		}
	});


	 $('#date').datepicker();
	 $('.paging a').each(function(){
		var url = ($(this).attr('href'));
		var page = (parseURL(url));
        $(this).attr('class','pagelink');  //or use $.trim($(this).text()) to remove white spaces.
		$(this).attr('value',page);  //or use $.trim($(this).text()) to remove white spaces.

	});


	function parseURL(theLink) {
		return decodeURI((RegExp("page" + '=' + '(.+?)(&|$)').exec(theLink) || [, null])[1]);
	}

	$('.paging a').click(function(event){
		 event.preventDefault();

		 var page1 = $(this).attr('value');
		 //alert(page1);
		 $('#page1').val(page1);
		 $("#id_submitbutton").click();
	 });
	var bodyid = "";
	$("#hrefcsv").click(function() {
		var hv = $('#csv').val();
		var params = $('#csvparams').val();
		document.location.href = 'csvdownload.php?query='+hv+'&queryparams='+params+'&format=csv';

	});
	$("#hrefcsvnotes").click(function() {
		var hv = $('#csv').val();
		var params = $('#csvparams').val();
		document.location.href = 'notesandfeedbackreport.php?query='+hv+'&queryparams='+params+'&format=csv';
	});
	$(".clear").click(function() {
		$('form[id="frmreport"]')
            .find(':radio, :checkbox').removeAttr('checked').end()
            .find('textarea, :text, select').val('')
		return false;
	});
	$("#exam").change(function() {
		var examid = $(this).val();
		var spinner = $('#loader');
		 $.ajax({
				url: 'loadsegment.ajax.php',
				method: 'post',
				data: {func: 'loadsegmentsvalues', examid: examid},
				dataType: 'json',
				beforeSend: function() { spinner.show(); },
				success: function(data) {
					spinner.hide();
					$("#segment option[value!='']").remove();
					 $.each(data.segments, function(i, value) {
						$('#segment').append($('<option>').text(value.name).attr('value', value.id));
					});

					$("#segment_group option[value!='']").remove();
					 $.each(data.groups, function(g, gvalue) {
						$('#segment_group').append($('<option>').text(gvalue.name).attr('value', gvalue.id));
					});

					$("#venue option[value!='']").remove();
					 $.each(data.venues, function(v, vvalue) {
						$('#venue').append($('<option>').text(vvalue.venuename).attr('value', vvalue.id));
					});

					$("#examiner option[value!='']").remove();
					 $.each(data.examiners, function(e, evalue) {
						$('#examiner').append($('<option>').text(evalue.firstname+' '+evalue.lastname).attr('value', evalue.id));
					});
				}
		});
	});

	$("#segment_group").change(function() {
		var spinner = $('#loader');
		var segmentids = $("#segment").val();
		var groupids = $(this).val();
		if(groupids!="" || groupids!=0){
		if(segmentids !=""){
			console.log("segmentids="+segmentids);
			console.log("groupids="+groupids);
			$.ajax({
				url: 'loadsegment.ajax.php',
				method: 'post',
				data: {func: 'loadvaluesbygroup', segmentids: segmentids,groupids:groupids},
				dataType: 'json',
				beforeSend: function() { spinner.show(); },
				success: function(data) {
					spinner.hide();
					console.log(data);
					$("#examiner option[value!='']").remove();
					 $.each(data.examiners, function(e, gvalue) {
						$('#examiner').append($('<option>').text(gvalue.name).attr('value', gvalue.id));
					});
				}
		});
		}
		else {
			alert("No segment selected");
		}
		} else {
			$("#segment_group option[value!='']").prop('selected', true);
			$("#segment_group").trigger("change");
		}
	});
	$("#venue").change(function() {
		if($(this).val() == "") {
			$("#venue option[value!='']").prop('selected', true);
		}
	});

	$("#examiner").change(function() {
		if($(this).val() == "") {
			$("#examiner option[value!='']").prop('selected', true);
		}
	});

	$("#consensusscore").change(function() {
		if($(this).val() == "") {
			//$("#consensusscore option[value!='']").prop('selected', true);
		}
	});

	$("#segment").change(function() {
		var segmentids = $(this).val();
		var spinner = $('#loader');

		var segmentids = (segmentids == ',') ? segmentids.substr(1) : segmentids;
		if(segmentids!="") {
		$.ajax({
				url: 'loadsegment.ajax.php',
				method: 'post',
				data: {func: 'loadvaluesbysegment', segmentids: segmentids},
				dataType: 'json',
				beforeSend: function() { spinner.show(); },
				success: function(data) {
					spinner.hide();
					$("#segment_group option[value!='']").remove();
					 $.each(data.groups, function(g, gvalue) {
						$('#segment_group').append($('<option>').text(gvalue.name).attr('value', gvalue.id));
					});

					$("#venue option[value!='']").remove();
					 $.each(data.venues, function(v, vvalue) {
						$('#venue').append($('<option>').text(vvalue.venuename).attr('value', vvalue.id));
					});

					$("#examiner option[value!='']").remove();
					 $.each(data.examiners, function(e, evalue) {
						$('#examiner').append($('<option>').text(evalue.firstname+' '+evalue.lastname).attr('value', evalue.id));
					});
				}
		});
		} else {
			$("#segment option[value!='']").prop('selected', true);
			$("#segment").trigger("change");
		}
	});
	$("#show").change(function() {
		// if(localStorage.getItem("reportfilter") === ""){
			// var hv = $('#csv').val();
			// alert(hv);
			// localStorage.setItem('reportfilter', hv);
			// $('#csv').val(hv);

		// }	else {
			// $('#csv').val(localStorage.getItem("reportfilter"));
			// alert($('#csv').val());
		// }
		var perpage =  $('#show').find(":selected").val();
		$('#perpage').val(perpage);
		$("#id_submitbutton").click();

	});
	$("#id_submitbutton").click(function(){
		localStorage.setItem('reportfilter', $('#csv').val());
	});
	$("#go").click(function(){
			   var href = 'result_reports.php?query=0';
               var e = $("#exam").val();
               var s = $("#segment").val();
			   var sg = $("#segment_group").val();
			   var start = $("#start").val();
			   var end = $("#end").val();
			   var v = $("#venue").val();
			   var examiner = $("#examiner").val();
			   var consensusscore = $("#consensusscore").val();

               if(e != null && e != "") {
                   href += '&examid='+e;
               }
               if(s != null && s != "") {
                   href += '&segments='+s;
               }
			   if(sg != null && sg != "") {
                   href += '&groups='+sg;
               }
			   if(start != null && start != "") {
                   href += '&startdate='+start;
               }
			   if(end != null && end != "") {
                   href += '&enddate='+end;
               }
			   if(v != null && v != "") {
                   href += '&venue='+v;
               }
			   if(examiner != null && examiner != "") {
                   href += '&examiner='+examiner;
               }
			   if(consensusscore != null && consensusscore !="") {
                   href += '&consensusscore='+consensusscore;
               }
			   if(consensusscore != null && consensusscore !="") {
                   href += '&consensusscore='+consensusscore;
               }
		//document.location.href=href;
		$('#filterdata').val(href);
    });

	$("#hrefchecklistcsv").click(function() {
		if($("#csv").val()=='' || $("#csv").val()=='checklistcsv') {
			$("#csv").val("checklistcsv");
			$("#frmreport").submit()
		}

	});
	$("#hreffeedbackcsv").click(function() {
		if($("#hreffeedbackcsv").val()=='' || $("#hreffeedbackcsv").val()=='feedbackcsv') {
			$("#csv").val("feedbackcsv");
			$("#frmreport").submit()
		}

	});
	$("#search").click(function() {
		$("#csv").val('');
		$("#frmreport").submit()
	});
	$('body').on('click', ".report", function() {
		var thisid = $(this).attr("id").split("/");
		 bodyid = $(this).attr("id");
		 var grade = $(this).closest('td').siblings("#total").html()
		 $.ajax({
			url: 'viewattempts.php',
			data: { exam:thisid[0], stationno: thisid[1],student:thisid[2],examiner:thisid[3],deviceid:thisid[4],score:grade},
			method: 'post',
			beforeSend: function(){
			   $("#divajaxquestions").dialog('open').html("<p>Please Wait...</p>");
			},
			success: function(data) {
				//alert("Test"+data);
				$('#divajaxquestions').html("<p>"+data+"</p>");
			 }
		});

	});
	 $("#divajaxquestions").dialog({
			position: { my: "right center", at: "right bottom", of: bodyid},
			title: 'View Attempts',
			width : 900,
			height : 768,
			resizable : true,
			modal : true,
			autoOpen: false,
			close: function () {

			}
	});

  });