<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Take Attendance
 *
 * @package    mod_studentattendance
 * @copyright  2011 Artem Andreev <andreev.artem@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(dirname(__FILE__).'/../../config.php');
require_once(dirname(__FILE__).'/locallib.php');
require($CFG->dirroot . '/mod/studentattendance/classes/structure.php');

$id     = required_param('id', PARAM_INT);

$sort       = optional_param('sort', '0', PARAM_INT);
$copyfrom   = optional_param('copyfrom', null, PARAM_INT);
$viewmode   = optional_param('viewmode', null, PARAM_INT);
$gridcols   = optional_param('gridcols', null, PARAM_INT);
$page     = optional_param('page', 0, PARAM_INT);
$perpage  = optional_param('perpage', 10, PARAM_INT);
$query    = optional_param('search', '', PARAM_TEXT);
$cm             = get_coursemodule_from_id('studentattendance', $id, 0, false, MUST_EXIST);
$course         = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
$att            = $DB->get_record('studentattendance', array('id' => $cm->instance), '*', MUST_EXIST);


if ($id) {
$cm     = get_coursemodule_from_id('studentattendance', $id, 0, false, MUST_EXIST);
$course = $DB->get_record('course', array(
    'id' => $cm->course
), '*', MUST_EXIST);
$cattendance   = $DB->get_record('studentattendance', array(
    'id' => $cm->instance
), '*', MUST_EXIST);
$cattendance->page = 'take';
} else if ($n) {
$cattendance   = $DB->get_record('studentattendance', array(
    'id' => $n
), '*', MUST_EXIST);
$cattendance->page = 'take';
$course = $DB->get_record('course', array(
    'id' => $cattendance->course
), '*', MUST_EXIST);
$cm     = get_coursemodule_from_instance('studentattendance', $cattendance->id, $course->id, false, MUST_EXIST);
} else {
error('You must specify a course_module ID or an instance ID');
}
require_login($course, true, $cm);
$context = context_module::instance($cm->id);

$url      = new moodle_url('/mod/studentattendance/take.php?id='.$id);
$PAGE->set_url($url);

//$PAGE->set_url($att->url_take());
$PAGE->set_title($course->shortname. ": ".$att->name);
$PAGE->set_heading($course->fullname);
$PAGE->set_cacheable(true);
$PAGE->requires->jquery();
$PAGE->requires->jquery_plugin('ui');
$PAGE->requires->jquery_plugin('ui-css');
$PAGE->requires->js('/mod/studentattendance/js/jquery.ui.timepicker.js');
$PAGE->requires->js('/mod/studentattendance/js/reports.js');
$PAGE->requires->css('/mod/studentattendance/css/jquery-ui.css');
//$PAGE->requires->css('/mod/studentattendance/css/jquery.ui.timepicker.css');
$module = array(
    'name' => 'mod_studentattendance_registeration',
    'fullpath' => '/mod/studentattendance/view.js',
    'requires' => array(
        'yui2-dom',
        'yui2-event',
        'yui2-container',
        'yui2-connection',
        'yui2-datatable',
        'yui2-paginator'
    ),
    'strings' => array(),
    'async' => false
);
$PAGE->requires->js_init_call('studentattendance_user_datatable_init', null, false, $module);
$cattendanceoutput       = $PAGE->get_renderer('mod_studentattendance');
$currenttab       = 'takeattendance';
$extraeditbuttons = true;
$extrapagetitle   = format_string('Take attendance');

echo $OUTPUT->header();
require($CFG->dirroot . '/mod/studentattendance/tabs.php');

$context_course = context_course::instance($course->id);
$user_records = get_enrolled_users($context_course, '', 0, '*');
$usercount = count($user_records);

echo html_writer::start_tag('form', array('method' => 'post', 'action' => ''));

$table                      = new html_table();
$table->head                = array();
$table->colclasses          = array();
$table->attributes['class'] = 'admintable generaltable';
$table->head[]              = 'Fistname';
$table->head[]              = 'Lastname';
$table->head[]              = 'Email';
$table->head[]              = 'P';
$table->head[]              = 'L';
$table->head[]              = 'E';
$table->head[]              = 'A';
$table->head[]              = 'Remarks';
$table->colclasses[]        = 'centeralign';
$table->id                  = "takeattendance";
echo html_writer::start_tag('div', array(
    'class' => 'no-overflow'
));
$count = 0;

foreach ($user_records as $key => $user_record) {
    $userinatt = $DB->get_record('studentattendance_details', array('attendanceid' => $cm->instance,
    'userid' => $user_record->id));
        $pchecked = array();
        $lchecked = array();
        $echecked = array();
        $achecked = array();
        $remks = isset($userinatt->remarks) ? $userinatt->remarks : '';

      if(!empty($userinatt->status)) {

        if($userinatt->status == "P") {
            $pchecked = array('checked' => 'checked');
        }
        if($userinatt->status == "L") {
            $lchecked = array('checked' => 'checked');
        }
        if($userinatt->status == "E") {
            $echecked = array('checked' => 'checked');
        }
        if($userinatt->status == "A") {
            $achecked = array('checked' => 'checked');
        }
    }

    $present   = array();
    $present[] = html_writer::empty_tag('input', array_merge($pchecked, array('type' => 'radio', 'class' => 'present', 'id' => 'p-'.$count, 'name' => 'attendance['.$count.'][atstatus]', 'value' => 'P')));
    $late   = array();
    $late[] = html_writer::empty_tag('input', array_merge($lchecked, array('type' => 'radio', 'id' => 'l-'.$count, 'name' => 'attendance['.$count.'][atstatus]', 'value' => 'L')));
    $excused   = array();
    $excused[] = html_writer::empty_tag('input', array_merge($echecked, array('type' => 'radio', 'id' => 'e-'.$count, 'name' => 'attendance['.$count.'][atstatus]', 'value' => 'E')));
    $absent   = array();
    $absent[] = html_writer::empty_tag('input', array_merge($achecked, array('type' => 'radio', 'id' => 'a-'.$count, 'name' => 'attendance['.$count.'][atstatus]', 'value' => 'A')));
    $attributes = array('type' => 'text', 'name' => 'attendance['.$count.'][remarks]', 'id' => 'remarks-'.$count, 'size' => 30, 'maxlength' => 100, 'value' => "$remks");
    $remarks = array();
    $remarks[$count] = html_writer::empty_tag('input', $attributes);
    $row           = array();
    $row[]         = html_writer::empty_tag('input', array('type' => 'hidden', 'name' => 'attendance['.$count.'][userid]', 'value' => $user_record->id)).$user_record->firstname;
    $row[]         = $user_record->lastname;
    $row[]         = $user_record->email;
    $row[]         = implode(' ', $present);
    $row[]         = implode(' ', $late);
    $row[]         = implode(' ', $excused);
    $row[]         = implode(' ', $absent);
    $row[]         = $remarks[$count];
    $table->data[] = $row;
    $count++;
}
$pagingbar = new paging_bar($usercount, $page, $perpage, $url . '?perpage=' . $perpage . $query);
//echo '<div class="" style="margin:0;">' . $OUTPUT->render($pagingbar) . '</div>';
echo html_writer::table($table);
//echo '<div class="" style="margin:0;">' . $OUTPUT->render($pagingbar) . '</div>';
echo html_writer::end_tag('div');
// Button to submit form.
echo html_writer::start_div('', array('style' => 'margin-top: 20px;float:right'));
echo html_writer::tag('button', 'Save Attendance');
echo html_writer::end_div();
echo html_writer::end_tag('form');

if(isset($_POST) && !empty($_POST['attendance'])){
    if(isset($id)) {
        foreach($_POST['attendance'] as $akey => $rvalue) {

            $record               = new stdClass();
            $record->attendanceid     = $cm->instance;
            $record->userid     = $rvalue['userid'];
            $record->remarks    = $rvalue['remarks'];
            $record->status     =  "";
            if(isset($rvalue['atstatus'])) {
                $record->status      = $rvalue['atstatus'];
            }
            $record->takenby = $USER->id;
            $record->timemodified = time();
            $useratt = $DB->get_record('studentattendance_details', array('attendanceid' => $cm->instance, 'userid' => $rvalue['userid']));
            if(empty($useratt)) {
                $DB->insert_record('studentattendance_details', $record);
            } else {
                $record->id = $useratt->id;
                $DB->update_record('studentattendance_details', $record);
            }

        }
        redirect(new moodle_url('/mod/studentattendance/take.php?id='.$cm->id), get_string('attendanceadd','studentattendance'), 3);
    }
}
echo $OUTPUT->footer();