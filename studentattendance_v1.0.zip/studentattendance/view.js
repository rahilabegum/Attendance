M.mod_exam = M.mod_exam || {};
function studentattendance_user_datatable_init(Y) {
	//YUI().use('node','yui2-dom','yui-base','yui2-event', 'yui2-container','yui2-calendar','datatype-date','yui2-connection', function (Y) {


	  Y.YUI2.util.Event.addListener(window, "load", function() {
	  Y.YUI2.example.EnhanceFromMarkup = new function() {/*
		 	var myColumnDefs = [
				{key:"name",sortable:true},
				{key:"start",sortable:true},
				{key:"end",sortable:true},
				{key:"pin",sortable:true},
				{key:"examvenue"}
			];


			var myColumn1Defs = [
				{key:"name",sortable:true},
				{key:"start",sortable:true},
				{key:"end",sortable:true},
				{key:"qrcode",sortable:true},
				{key:"examvenue"}
			];

			this.myDataSource = new Y.YUI2.util.DataSource(Y.YUI2.util.Dom.get("examinerstable"));
			this.myDataSource.responseType =  Y.YUI2.util.LocalDataSource.TYPE_HTMLTABLE;
			this.myDataSource.responseSchema = {
				fields: [{key:"name"},
						{key:"start"},
						{key:"end"},
						{key:"pin"},
						{key:"examvenue"}]
			};

			this.myDataSource1 = new Y.YUI2.util.DataSource(Y.YUI2.util.Dom.get("candidatetables"));
			this.myDataSource1.responseType =  Y.YUI2.util.LocalDataSource.TYPE_HTMLTABLE;
			this.myDataSource1.responseSchema = {
				fields: [{key:"name"},
						{key:"start"},
						{key:"end"},
						{key:"qrcode"},
						{key:"examvenue"}]
			};

			var oConfigs = {
	                paginator: new Y.YUI2.widget.Paginator({
	                    rowsPerPage: 5
	                })
	        };

			var oConfigs1 = {
	                paginator: new Y.YUI2.widget.Paginator({
	                    rowsPerPage: 5
	                })
	        };

			this.myDataTable = new  Y.YUI2.widget.DataTable("paging", myColumnDefs, this.myDataSource,oConfigs
			);

			this.myDataTable1 = new  Y.YUI2.widget.DataTable("pagingcan", myColumn1Defs, this.myDataSource1,oConfigs1
			);

			//var myDataTable = new YAHOO.widget.DataTable("paginated", myColumnDefs, myDataSource, oConfigs);

		 */};
	 });
	//});
}
YUI().use('node','yui2-dom','yui-base','yui2-event', 'yui2-container','yui2-calendar','datatype-date','yui2-connection','uploader', 'datatable', 'datatable-paginator', 'datatype-number', function (Y) {
	var studentattendance_reports = {};
	Y.delegate("click", function(e) {
	var divsearchpopup = Y.YUI2.util.Dom.get('divsearchpopup');
	studentattendance_reports.divsearchpopup = new Y.YUI2.widget.Dialog('divsearchpopup', {
				modal: true,
				width: '800px',
				iframe: true,
				zIndex: 1000, // zIndex must be way above 99 to be above the active quiz tab
				fixedcenter: true,
				visible: false,
				close: true,
				constraintoviewport: true,
		});
		studentattendance_reports.divsearchpopup.render();
		var div = document.getElementById('divsearchpopup');
			if (div) {
				div.style.display = 'block';
			}
		studentattendance_reports.divsearchpopup.show();
		Y.all('.container-close').on('click', function (e) {
			studentattendance_reports.divsearchpopup.hide();
		})

}, Y.one("body"), ".searchbutton");
Y.delegate("click", function(e) {
	 thisid = this.get('id');
	 thisval = this.get('name').split("~");
	 examid = thisval[1];

	 window.location.href="downloadqrcodepdf.php?examid="+examid+"&userid="+thisid;
}, Y.one("body"), ".downloadQRcode");



var examinerselectall = Y.one('#examinerselectall');
Y.delegate("click", function(e) {
     //   studentselectall.on('change', function(e) {
            if (e.currentTarget.get('checked')) {
                checkboxes =  Y.all('.examinerchckbox');
                checkboxes.each(function(node) {
					if(!node.get('disabled'))
                    node.set('checked', true);
                });
            } else {
                checkboxes = Y.all('.examinerchckbox');
                checkboxes.each(function(node) {
					if(!node.get('disabled'))
                    node.set('checked', false);
                });
            }
      //  })
}, Y.one("body"), "#examinerselectall");


var studentselectall = Y.one('#studentselectall');
Y.delegate("click", function(e) {
     //   studentselectall.on('change', function(e) {
            if (e.currentTarget.get('checked')) {
                checkboxes =  Y.all('.studentchckbox');
                checkboxes.each(function(node) {
					if(!node.get('disabled'))
                    node.set('checked', true);
                });
            } else {
                checkboxes = Y.all('.studentchckbox');
                checkboxes.each(function(node) {
					if(!node.get('disabled'))
                    node.set('checked', false);
                });
            }
      //  })
}, Y.one("body"), "#studentselectall");

var teststudentselectall = Y.one('#teststudentselectall');
Y.delegate("click", function(e) {
     //   studentselectall.on('change', function(e) {
            if (e.currentTarget.get('checked')) {
                checkboxes =  Y.all('.teststudentchckbox');
                checkboxes.each(function(node) {
					if(!node.get('disabled'))
                    node.set('checked', true);
                });
            } else {
                checkboxes = Y.all('.teststudentchckbox');
                checkboxes.each(function(node) {
					if(!node.get('disabled'))
                    node.set('checked', false);
                });
            }
      //  })
}, Y.one("body"), "#teststudentselectall");

Y.delegate("click", function(e) {
		studentcheckboxes =  Y.all('.studentchckbox');
		studentids = "";
		studentcheckboxes.each(function(node) {
			if (node.get('checked') && !node.get('disabled')) {
				studentids=studentids+node.get('id')+"~";
			 }
		});
		studentids = studentids.replace(/~+$/, "");
		if(studentids=="") {
			alert("Please select the candidates");
			return false;
		}
		//alert(studentids);
		thisval = this.get('name').split("~");
		examid = thisval[1];
		var params = "studentsid="+studentids;

		window.location.href="downloadqrcodepdf.php?examid="+examid+"&userid="+studentids;
		 //arrname = this.name.split("~");
		 //alert(arrname[1]);
		 //var params = "examid="+arrname[1]+"&studentsid="+studentids;
		 //thisid = this.get('id');
		 //examid = 2; selecteduser
		 //window.location.href="downloadqrcodepdf.php?examid="+examid+"&userid="+thisid;
}, Y.one("body"), ".downloadQRcodemultiuser");

Y.delegate("click", function(e) {
		teststudentcheckboxes =  Y.all('.teststudentchckbox');
		teststudentids = "";
		teststudentcheckboxes.each(function(node) {
			if (node.get('checked') && !node.get('disabled')) {
				teststudentids=teststudentids+node.get('id')+"~";
			 }
		});
		teststudentids = teststudentids.replace(/~+$/, "");
		if(teststudentids=="") {
			alert("Please select the test candidates");
			return false;
		}
		//alert(studentids);
		thisval = this.get('name').split("~");
		examid = thisval[1];
		var params = "studentsid="+teststudentids;

		window.location.href="downloadqrcodepdf.php?examid="+examid+"&userid="+teststudentids;
		 //arrname = this.name.split("~");
		 //alert(arrname[1]);
		 //var params = "examid="+arrname[1]+"&studentsid="+studentids;
		 //thisid = this.get('id');
		 //examid = 2; selecteduser
		 //window.location.href="downloadqrcodepdf.php?examid="+examid+"&userid="+thisid;
}, Y.one("body"), ".downloadTQRcodemultiuser");

Y.delegate("click", function(e) {
		thisval = this.get('name').split("~");
		examid = thisval[1];
		examinerids = "";
		studentids = "";
		teststudentids = "";
		studentcheckboxes =  Y.all('.studentchckbox');
		examinercheckboxes =  Y.all('.examinerchckbox');
		teststudentcheckboxes =  Y.all('.teststudentchckbox');

		if(thisval[0] == 'downloadCRD'){
			roletype = 5;
			studentcheckboxes.each(function(node) {
				if (node.get('checked') && !node.get('disabled')) {
					studentids=studentids+node.get('id')+"~";
				 }
			});
			studentids = studentids.replace(/~+$/, "");
			if(studentids=="") {
				alert("Please select the candidates");
				return false;
			}
			window.location.href="downloaduserregisteration.php?examid="+examid+"&roletype="+roletype+"&userids="+studentids;

			examinercheckboxes =  Y.all('.examinerchckbox');

		}
		else if(thisval[0] == 'downloadTCRD'){
			roletype = 11;
			teststudentcheckboxes.each(function(node) {
				if (node.get('checked') && !node.get('disabled')) {
					teststudentids=teststudentids+node.get('id')+"~";
				 }
			});
			teststudentids = teststudentids.replace(/~+$/, "");
			if(teststudentids=="") {
				alert("Please select the test candidates");
				return false;
			}
			window.location.href="downloaduserregisteration.php?examid="+examid+"&roletype="+roletype+"&userids="+teststudentids;

			examinercheckboxes =  Y.all('.examinerchckbox');

		}
		else {
			roletype = 2;
			examinercheckboxes.each(function(node) {
				if (node.get('checked') && !node.get('disabled')) {
					examinerids=examinerids+node.get('id')+"~";
				 }
			});
			examinerids = examinerids.replace(/~+$/, "");
			if(examinerids=="") {
				alert("Please select the examiners");
				return false;
			}
			window.location.href="downloaduserregisteration.php?examid="+examid+"&roletype="+roletype+"&userids="+examinerids;
		}
	}, Y.one("body"), ".downloadusercsv");

	Y.delegate("click", function(e) {
		thisval = this.get('id').split("~");
		userid = thisval[0];
		examid = thisval[1];
		var params = "userid="+userid+"&examid="+examid;
		Y.YUI2.util.Connect.asyncRequest('POST', 'resetpin.php?random='+Math.random(), callbackpin,params);
		//alert(userid);
		//alert(examid);
}, Y.one("body"), ".resetpin");

callbackpin = {
		success:function(o) {
			responsetext = o.responseText
				//alert(responsetext);
				alert('PIN has been reset Successfully');
		},
		failure:function(o) {
			alert('PIN has not been reset Successfully');
		}
	}

Y.delegate("click", function(e) {
	thisval = this.get('name').split("~");
	examid = thisval[1];
	id = -1;
	window.location.href="editadvanced.php?id="+id+"&examid="+examid+"&role=student";
}, Y.one("body"), ".addcandidates");

Y.delegate("click", function(e) {
	thisval = this.get('name').split("~");
	examid = thisval[1];
	id = -1;
	window.location.href="editadvanced.php?id="+id+"&examid="+examid+"&role=testcandidate";
}, Y.one("body"), ".addtestcandidates");

$('body').delegate('form#mform1', 'submit', function(e) {
		//alert(Y.one('#id_submitbutton').get('value'));
		buttonvalue = Y.one('#id_submitbutton').get('value');

		if(buttonvalue == "Reupload Users"){
			if(Y.all('.filepicker-filename a').get('html') != ''){
				var conf = confirm("You are about to add new examiners and/or candidates to this exam. Do you want to proceed?");
				if(conf) {
					return true;
				}
				else{
					return false;
				}
			}
			else {
				return true;
			}
		}
		else{
			return true;
		}
    });
});


