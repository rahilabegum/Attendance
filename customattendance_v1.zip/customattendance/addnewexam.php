<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Local segment_admin addnewexam.
 *
 * @package    local_segment_admin
 * @category   views
 * @copyright 2019 Your Name <your@email.address>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/authlib.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->dirroot . '/mod/customattendance/lib/userfilters.php');
$action = optional_param('action', '', PARAM_TEXT);
require_login();

admin_externalpage_setup("segment_admin_new_exam");
$PAGE->set_url('/mod/customattendance/addnewsession.php');
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->requires->jquery();
$examid = optional_param('id', 0, PARAM_INT);
$exam   = $DB->get_record('admin_segment_exam', array(
    'id' => $examid
));
$countrecords = $DB->get_records_sql("SELECT *
									FROM {segment}
									WHERE (publishstatus = 0 or completestatus =0) and exam=?", array($examid));
class examcreate_form extends moodleform
{
    private $isactive;
    public function definition() {
        global $CFG, $examid;
        $mform =& $this->_form; // Don't forget the underscore!
        $mform->addElement('hidden', 'id', $examid);
        $mform->addElement('hidden', 'activateexam');
        $mform->setType('id', PARAM_INT);
        $mform->addElement('text', 'customattendancename', get_string('customattendancename','customattendance'), array(
            'style' => 'width:330px'
        ));
        $mform->addHelpButton('customattendancename', 'customattendancename','customattendance');
        $mform->addRule('customattendancename', 'Please Enter Exam Name', 'required', null, 'client');
        $mform->setType('customattendancename', PARAM_TEXT);
        $mform->setType('activateexam', PARAM_RAW);
        $mform->addElement('date_time_selector', 'startdate', get_string('startdate','customattendance'));
        $mform->setDefault('startdate', time() + 3600 * 24);
        $mform->addHelpButton('startdate', 'startdate','customattendance');
        $mform->addElement('date_time_selector', 'enddate', get_string('enddate','customattendance'));
        $mform->setDefault('enddate', time() + 3600 * 24);
        $mform->addHelpButton('enddate', 'enddate','customattendance');
    }
    // Custom validation should be added here.
    public function validation($data, $files) {
        global $DB;
        if (isset($data['cancel'])) {
            redirect(new moodle_url('/mod/customattendance/listsession.php'));
            exit;
        }
        $recordexist = $DB->get_records_sql("select * from {admin_segment_exam}
        where id <> " . $data['id'] . " and customattendancename='" . trim($data['customattendancename']) . "'");
        $errors      = parent::validation($data, $files);
        if (!empty($recordexist)) {
            $errors['customattendancename'] = get_string('examexits','customattendance');
        }
        if (trim($data['customattendancename']) == '') {
            $errors['customattendancename'] = get_string('customattendancename_help','customattendance');
        }
        if ($data['enddate'] <= $data['startdate']) {
            $errors['enddate'] = get_string('enddategreater','customattendance');
        }
        return $errors;
    }
    public function definition_after_data() {
        parent::definition_after_data();
        global $CFG, $DB, $examid, $OUTPUT;
        $mform =& $this->_form;
        $activateexam = ($mform->getElementValue('activateexam') == 1) ? 'checked' : '';
        $countrecords = $DB->get_records_sql("SELECT *
												FROM {segment}
												WHERE (publishstatus = 0 or completestatus =0) and exam=?", array($examid));
        if ($examid && !empty($countrecords)) {
            $disabled = 'disabled';
        } else {
            $disabled = '';
        }
        $mform->addElement('html', '<div id="fitem_id_examactive" class="fitem fitem_ftext form-group row  fitem"><div class="fitemtitle col-md-3">
         <label for="id_examactive">Active</label>'.$OUTPUT->help_icon('activateexam','customattendance').'</div>
         <div class="felement ftext">
         <label class="switch">
         <input type="checkbox" class="examCheckboxes" ' . $activateexam . ' name="activate_exam" ' . $disabled . '>
         <span class="slider round"></span></label></div></div>');
        $this->add_action_buttons(true, 'Submit');
    }
}

$mform = new examcreate_form();
if ($mform->is_cancelled()) {
    redirect(new moodle_url('/mod/customattendance/listsession.php'));
} else if ($data = $mform->get_data()) {
    if (isset($data->cancel)) {
        redirect(new moodle_url('/mod/customattendance/listsession.php'));
        exit;
    }
    if ($data) {
        $record               = new stdClass();
        $record->customattendancename     = $data->customattendancename;
        $record->startdate    = $data->startdate;
        $record->enddate      = $data->enddate;
        $record->activateexam = $data->activateexam;
        $record->timemodified = time();
        if (!$examid) {
            $record->timecreated = time();
            $DB->insert_record('admin_segment_exam', $record);
            redirect(new moodle_url('/mod/customattendance/listsession.php'), get_string('sessionadd','customattendance'), 3);
        } else {
            $record->id = $examid;
            $DB->update_record('admin_segment_exam', $record);
            redirect(new moodle_url('/mod/customattendance/listsession.php'),
            get_string('sessionupdate','customattendance'), 3);
        }
    }
} else {
    $update = $DB->get_record('admin_segment_exam', array(
        'id' => $examid
    ));
    $mform->set_data($update);
    echo $OUTPUT->header();
    echo $OUTPUT->heading(($action == 'edit') ?
    get_string('editexam','customattendance') : get_string('addnewexam','customattendance'));
    $mform->display();
    if ($action == 'edit') {
        echo html_writer::empty_tag('br', array(
            'clear' => 'all'
        ));
        echo html_writer::empty_tag('br', array(
            'clear' => 'all'
        ));
        echo html_writer::tag('strong', 'Segments in Exam : ');
        echo html_writer::empty_tag('br', array(
            'clear' => 'all'
        ));
        echo html_writer::empty_tag('br', array(
            'clear' => 'all'
        ));
        $segments = $DB->get_records_sql("SELECT a.id,
			   a.name,
			   a.publishstatus,
               a.completestatus,
			   b.name AS specialityb,
			   c.segmenttype,
			   d.customattendancename
		FROM {segment} a
		JOIN {admin_segment_speciality} b ON b.id=a.speciality
		JOIN {admin_segment_segmenttype} c ON c.id=a.segmenttype
		JOIN {admin_segment_exam} d ON d.id=a.exam
        WHERE a.exam=? order by a.id DESC", array($examid));
        // Table list.
        echo '<style>
     .generaltable .header{vertical-align:top;}
     .generaltable{border:1px solid #cdcdcd;}
     </style>';
        $table                      = new html_table();
        $table->head                = array();
        $table->colclasses          = array();
        $table->attributes['class'] = 'admintable generaltable';
        $table->head[]              = get_string('segmentname','customattendance');
        $table->head[]              = get_string('speciality','customattendance');
        $table->head[]              = get_string('segmenttype','customattendance');
        $table->head[]              = get_string('examdateandtime','customattendance');
        $table->head[]              = get_string('status','customattendance');
        $table->head[]              = get_string('completestatus','customattendance');
        $table->colclasses[]        = 'centeralign';
        $table->id                  = "segments";
        $dateformat                 = get_string('strftimedatetime');
        $examdate                   = userdate($update->startdate, $dateformat);
        echo html_writer::start_tag('div', array(
            'class' => 'no-overflow'
        ));
        foreach ($segments as $key => $segment) {
            $row           = array();
            $cm            = get_coursemodule_from_instance('segment', $segment->id, $segment->course, false, MUST_EXIST);
            $details       = new moodle_url('/mod/segment/listsession.php?id=' . $cm->id);
            $a = $segment->id.'~1';
            $b = $segment->id.'~0';
            $selected = (isset($segment->completestatus) && $segment->completestatus == 1 && $segment->publishstatus == 1) ?
                        'selected' : '';
            $bselected = (isset($segment->completestatus) && $segment->publishstatus == 1 && $segment->completestatus == 0) ?
                          'selected' : '';
            $row[]         = html_writer::link($details, $segment->name);
            $row[]         = $segment->specialityb;
            $row[]         = $segment->segmenttype;
            $row[]         = $examdate;
            $row[]         = (isset($segment->publishstatus) && $segment->publishstatus == 1) ? 'Published' : 'Open';
            $row[]         = (isset($segment->publishstatus) && $segment->publishstatus == 1) ?
                             '<select name="status" class="cstatus" >
                              <option id="1" value="'.$a.'" '.$selected.'>'.$selected.'Completed</option>
                              <option id="2" value="'.$b.'" '.$bselected.'>In-Complete</option>
                              </select>' : '-<select name="status" class="cstatus" style="visibility: hidden;">
                              <option id="2" value="'.$b.'" '.$bselected.'>In-Complete</option>
                              </select>';
            $table->data[] = $row;
        }
        echo html_writer::table($table);
        // End.
    }
}

?>
<script src="js/jquery.validate.min.js"></script>
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 30px;
}
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}
.slider:before {
  position: absolute;
  content: "";
  height: 22px;
  width: 22px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}
input:checked + .slider {
    background-color: green;

<?php
$countrecords = $DB->get_records_sql("SELECT *
									FROM {segment}
								    WHERE (publishstatus = 0 or completestatus =0) and exam=?", array($examid));
if ($examid && !empty($countrecords)) {
?>
           opacity :0.2;
    <?php
}
?>
   }
input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}
input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}
/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}
.slider.round:before {
  border-radius: 50%;
}
#loader {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: rgba(0,0,0,0.5) url('../../../pix/i/loading.gif') no-repeat center center;
  z-index: 10000;
}
</style>
<script>
$(document).ready(function() {
<?php
$countrecords = $DB->get_records_sql("SELECT *
									FROM {segment}
								    WHERE (publishstatus = 0 or completestatus =0) and exam=?", array($examid));
if ($examid && !empty($countrecords)) {
?>
 $('input#id_submitbutton').prop('disabled', true);
<?php
}
?>
   $( "input[name='activate_exam']" ).click(function() {
        if($(this).prop("checked") == true){
            $( "input[name='activateexam']" ).val("1");
        }
        else if($(this).prop("checked") == false){
            $( "input[name='activateexam']" ).val("0");
        }
    });
    $(".cstatus").change(function () {
        var cstatus = $(this).val();
        var selectedtext,i = 0;
        var spinner = $('#loader');
            $.ajax({
            url: "ajaxvalidation.php",
            type: "get",
            data:  {'action':"completedstatus", 'sid':cstatus},
            dataType: "json",
            beforeSend: function() { spinner.show(); },
            success: function(response){
                if(response){
                    spinner.hide();
                }
            }
        });
    $('.cstatus option:selected').each(function(){
       selectedtext =$(this).text();
       if(selectedtext != 'Completed'){
        i++ ;
        }
        if(i == 0){
        $('.examCheckboxes').prop("disabled", false);
        $('#id_submitbutton').prop("disabled", false);
        $('input:checked + .slider').css("opacity", "1");
        $('.slider').css("opacity", "1");
        }else{
        $('.examCheckboxes').prop("disabled", true);
        $('#id_submitbutton').prop("disabled", true);
        $('input:checked + .slider').css("opacity", "0.2");
        }
        });
    });
});
</script>
<div id="loader"></div>
<?php
echo $OUTPUT->footer();