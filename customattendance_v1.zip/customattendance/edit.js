// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * JavaScript library for the quiz module editing interface.
 *
 * @package    mod
 * @subpackage quiz
 * @copyright  2008 Olli Savolainen
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


// Initialise everything on the quiz edit/order and paging page.
var customattendance_edit = {};
// Initialise everything on the quiz settings form.
localStorage.clear();
function customattendance_settings_init(Y) {
        var qppselect = document.getElementById('ManageVenue');
        var divmanagevenuepopup = Y.YUI2.util.Dom.get('divmanagevenuepopup');
        var divvenuepopup = Y.YUI2.util.Dom.get('venuepopup');
        customattendance_edit.divmanagevenuepopup = new Y.YUI2.widget.Dialog('divmanagevenuepopup', {
            modal: true,
            width: '800px',
            iframe: true,
            zIndex: 1000, // ZIndex must be way above 99 to be above the active quiz tab.
            fixedcenter: true,
            visible: false,
            close: true,
            constraintoviewport: true,
        });
        customattendance_edit.divmanagevenuepopup.render();
        Y.YUI2.util.Event.addListener(qppselect, 'click', function(e) {
            var divvenuepopup = Y.YUI2.util.Dom.get('venuepopup');
            Y.all('.singleform').hide();
            Y.all('.venuelist').show();
            Y.one('#venuelist').show();
            Y.one('#venuepopup').addClass('borderadd');
            Y.one('#venuepopup').removeClass('borderremove');
            var div = document.getElementById('divmanagevenuepopup');
            if (divmanagevenuepopup) {
                divmanagevenuepopup.style.display = 'block';
                Y.one('#venuepopup').show();
            }
            customattendance_edit.divmanagevenuepopup.show();
            Y.all('.container-close').on('click', function (e) {
                        customattendance_edit.divmanagevenuepopup.hide();
            })
        });
    Y.delegate("click", function(e) {
        thisid = this.get('id');
        Y.one('#managevenue').set("value", Y.one('#venuename'+thisid).get('innerHTML'));
        Y.all('.venuelist').hide();
        Y.all('.singleform').show();
        Y.one('#venuepopup').addClass('borderremove');
        Y.one('#venuepopup').removeClass('borderadd');
        if (divsinglevenuepopup) {
            divsinglevenuepopup.style.display = 'block';
        }
        customattendance_edit.divmanagevenuepopup.show();
    }, Y.one("body"), ".venueedit");

    Y.delegate("click", function(e) {
        thisid = this.get('id');
        Y.one('#managevenue').set("value", '');
        Y.all('.venuelist').hide();
        Y.all('.singleform').show();
        Y.one('#venuepopup').addClass('borderremove');
        Y.one('#venuepopup').removeClass('borderadd');
        var divsinglevenuepopup = document.getElementById('singlevenuepopup');
        if (divsinglevenuepopup) {
            divsinglevenuepopup.style.display = 'block';
        }
        customattendance_edit.divmanagevenuepopup.show();

    }, Y.one("body"), "#addvenue");
    Y.delegate("click", function(e) {
        var divmanagevenuepopup = Y.YUI2.util.Dom.get('divmanagevenuepopup');
        if (divmanagevenuepopup) {
            divmanagevenuepopup.style.display = 'block';
            Y.all('.venuelist').show();
            Y.all('.singleform').hide();
            Y.one('#venuepopup').addClass('borderadd');
            Y.one('#venuepopup').removeClass('borderremove');
        }
    }, Y.one("body"), "#cancelvenue");
}