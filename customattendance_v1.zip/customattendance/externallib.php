<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Externallib.php file for attendance plugin.
 *
 * @package    mod_customattendance
 * @copyright  2015 Caio Bressan Doneda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir . '/externallib.php');
require_once($CFG->libdir . '/filelib.php');

/**
 * Class mod_customattendance_external
 * @copyright  2015 Caio Bressan Doneda
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_customattendance_external extends external_api {
    /**
     * Get structure of an attendance session.
     *
     * @return array
     */


    /**
     * Get session params.
     *
     * @return external_function_parameters
     */
    public static function get_session_parameters() {
        return new external_function_parameters(array(
            'email' => new external_value(PARAM_TEXT, 'email id'),
            'cname' => new external_value(PARAM_TEXT, 'shortname')
        ));

    }

    /**
     * Get session.
     *
     * @param int $sessionid
     * @return mixed
     */
    public static function get_session($email, $cname) {
        global $DB;
        // Check user id is valid.
        $user = $DB->get_record('user', array('email' => $email), '*', MUST_EXIST);
        $course = $DB->get_record('course', array('shortname' => $cname), '*', MUST_EXIST);
        $userid = $user->id;
        $courseid = $course->id;
        $attendance = $DB->get_record('customattendance', array('course' => $courseid), '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('customattendance', $attendance->id, 0, false, MUST_EXIST);
        $sessionstatus = array();
        $sessionstatus['userid'] = $userid;
        $sessionstatus['courseid'] = $courseid;
        $sessionstatus['coursename'] = $course->fullname;
        $sessionstatus['attendanceid'] = $attendance->id;
        $sessionstatus['attendancename'] = $attendance->name;
        $sessions = $DB->get_records('customattendance_sessions', array('attendanceid' => $cm->instance));
        foreach($sessions as $key => $session) {
            $sessionsusers = $DB->get_records('customattendance_usersession', array('attendanceid' => $cm->instance,'userid' => $userid));
            foreach($sessionsusers as $ukey => $sessionsuser) {
                $sessionstatus['sessionstatus'][$ukey]['id']= $sessionsuser->id;
                $sessionstatus['sessionstatus'][$ukey]['status']= $sessionsuser->status;
                $sessionstatus['sessionstatus'][$ukey]['remarks']= $sessionsuser->remarks;
            }
        }
        $params = self::validate_parameters(self::get_session_parameters(), array(
            'email' => $email,
            'cname' => $cname
        ));

        return array('userattendance' => $sessionstatus);
    }

    /**
     * Show return values of get_session.
     *
     * @return external_single_structure
     */
    public static function get_session_returns() {
        return new external_multiple_structure(new external_single_structure(array(
            'userid' => new external_value(PARAM_INT, 'segment id'),
            'courseid' => new external_value(PARAM_INT, 'course id'),
            'coursename' => new external_value(PARAM_TEXT, 'segment name'),
            'attendanceid' => new external_value(PARAM_INT, 'assessment date'),
            'attendancename' => new external_value(PARAM_TEXT, 'attendance name'),
            'sessionstatus' => new external_multiple_structure(new external_single_structure(array(
                'id' => new external_value(PARAM_INT, 'attempt id'),
                'status' => new external_value(PARAM_TEXT, 'assessment mark'),
                'remarks' => new external_value(PARAM_TEXT, 'quiz mark'),
            )))
        )));
        }
    }
    /****Eg: *******/
    /*http://localhost/moodle39/moodle/webservice/rest/server.php?moodlewsrestformat=json&wstoken=857d93c985e127dec2588f1dc06764c0&wsfunction=mod_customattendance_get_session*/
