<?php
// This file is part of Moodle Exam Module - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Exam User Registration View
 *
 * @package    mod_exam
 * @Author     Ramya
 * @copyright  2015 Royal Australian College of Surgeons.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once('../../config.php');
require_once('./lib.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/csvlib.class.php');
require_once($CFG->dirroot . '/user/profile/lib.php');
require_once($CFG->dirroot . '/user/lib.php');

$id          = optional_param('id', 0, PARAM_INT); // Course_module ID , or
$n           = optional_param('n', 0, PARAM_INT);
global $DB;
if ($id) {
    $cm     = get_coursemodule_from_id('customattendance', $id, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', array(
        'id' => $cm->course
    ), '*', MUST_EXIST);
    $cattendance   = $DB->get_record('customattendance', array(
        'id' => $cm->instance
    ), '*', MUST_EXIST);
} else if ($n) {
    $cattendance   = $DB->get_record('customattendance', array(
        'id' => $n
    ), '*', MUST_EXIST);
    $course = $DB->get_record('course', array(
        'id' => $cattendance->course
    ), '*', MUST_EXIST);
    $cm     = get_coursemodule_from_instance('customattendance', $cattendance->id, $course->id, false, MUST_EXIST);
} else {
    error('You must specify a course_module ID or an instance ID');
}
$cattendance->page = '';
$PAGE->set_url('/mod/customattendance/listsession.php');
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->requires->jquery();
$action   = optional_param('action', '', PARAM_TEXT);
$id       = optional_param('id', '0', PARAM_INT);
$page     = optional_param('page', 0, PARAM_INT);
$perpage  = optional_param('perpage', 10, PARAM_INT);
$query    = optional_param('search', '', PARAM_TEXT);
$callback = optional_param('callback', '', PARAM_TEXT);
$url      = new moodle_url('/mod/customattendance/listsession.php');
$PAGE->set_url($url);
if ($page !== 0) {
    $url->param('page', $page);
}
if ($action == 'delete') {
    $DB->delete_records('customattendance_sessions', array(
        'id' => $id
    ));
    redirect(new moodle_url('/mod/customattendance/listsession.php'), get_string('examremove','customattendance'), 3);
}

require_login($course, true, $cm);
$coursecontext = context_course::instance($cattendance->course);
require_capability('mod/customattendance:access', $coursecontext);
$extrapagetitle   = format_string($cattendance->name);
$PAGE->set_url('/mod/customattendance/listsession.php', array(
    'id' => $cm->id
));
$PAGE->set_title(format_string($cattendance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->requires->jquery();
$PAGE->requires->jquery_plugin('ui');
$module = array(
    'name' => 'mod_customattendance_registeration',
    'fullpath' => '/mod/customattendance/view.js',
    'requires' => array(
        'yui2-dom',
        'yui2-event',
        'yui2-container',
        'yui2-connection',
        'yui2-datatable',
        'yui2-paginator'
    ),
    'strings' => array(),
    'async' => false
);
$PAGE->requires->js_init_call('customattendance_user_datatable_init', null, false, $module);
$cattendanceoutput       = $PAGE->get_renderer('mod_customattendance');
$currenttab       = 'listsessions';
$extraeditbuttons = true;
$extrapagetitle   = format_string($cattendance->name);
echo $OUTPUT->header();

require($CFG->dirroot . '/mod/customattendance/tabs.php');

if (isset($query) && !empty($query)) {
    $cattendances         = $DB->get_records_sql("SELECT * FROM {customattendance_sessions} WHERE name
	LIKE '%" . $query . "%' ORDER BY id desc LIMIT " . $perpage . " OFFSET " . ($page * $perpage));
    echo ("SELECT * FROM {customattendance_sessions} WHERE name
	LIKE '%" . $query . "%' ORDER BY id desc LIMIT " . $perpage . " OFFSET " . ($page * $perpage));
    $segmentcount = $DB->get_records_sql("SELECT count(*) as segcount FROM {customattendance_sessions}
	WHERE name LIKE '%" . $query . "%'");
    $countvalues  = (array_keys($segmentcount));
    $sementscount  = $countvalues[0];
    $querystr      = "&search=" . $query;

} else {

    $cattendances        = $DB->get_records('customattendance_sessions', array(), 'id ASC', '*', ($page * $perpage), $perpage);
    $sementscount = $DB->count_records('customattendance_sessions', array());
    $querystr     = "";
}
// Add filters.
$table                      = new html_table();
$table->head                = array();
$table->colclasses          = array();
$table->attributes['class'] = 'admintable generaltable';
$table->head[]              = get_string('sessionname','customattendance');
$table->head[]              = get_string('sessiondate','customattendance');
$table->head[]              = get_string('sessionstarttime','customattendance');
$table->head[]              = get_string('sessionendtime','customattendance');
$table->head[]              = get_string('action','customattendance');
$table->colclasses[]        = 'centeralign';
$table->id                  = "sessionlist";
echo html_writer::start_tag('div', array(
    'class' => 'no-overflow'
));
foreach ($cattendances as $key => $cattendance) {
    $buttons   = array();
    $buttons[] = html_writer::link(new moodle_url($CFG->wwwroot . '/mod/customattendance/take.php', array(
        'id' => $cm->id, 'sessionid' =>  $cattendance->id
    )), html_writer::empty_tag('img', array(
        'src' => $OUTPUT->image_url('t/collapsed'),
        'alt' => '',
        'class' => 'iconsmall'
    )), array(
        'title' => ''
    ));
    $buttons[] = html_writer::link(new moodle_url($CFG->wwwroot . '/mod/customattendance/addnewsession.php?action=edit', array(
        'mid' => $cm->id, 'sessionid' =>  $cattendance->id
    )), html_writer::empty_tag('img', array(
        'src' => $OUTPUT->image_url('t/edit'),
        'alt' => '',
        'class' => 'iconsmall'
    )), array(
        'title' => ''
    ));
    $row           = array();
    $row[]         = $cattendance->name;
    $row[]         = userdate($cattendances[$cattendance->id]->sessdate);
    $row[]         = userdate($cattendances[$cattendance->id]->sessdate, '%H:%M:%S');
    $row[]         = userdate($cattendances[$cattendance->id]->lasttaken, '%H:%M:%S');
    $row[]         = implode(' ', $buttons);
    $table->data[] = $row;
}
$search = html_writer::start_tag('form', array(
    'id' => 'searchcohortquery',
    'method' => 'get'
));
$search .= html_writer::end_tag('form');
echo $search;
$pagingbar = new paging_bar($sementscount, $page, $perpage, $url . '?perpage=' . $perpage . $querystr);
echo '<div class="" style="margin:0;">' . $OUTPUT->render($pagingbar) . '</div>';
echo html_writer::table($table);
echo '<div class="" style="margin:0;">' . $OUTPUT->render($pagingbar) . '</div>';
echo html_writer::end_tag('div');
?>
<script>
$(document).ready(function() {
    $('.deleteid').click(function(event) {
    event.preventDefault();
    var r=confirm("Are you sure want to delete?");
        if (r==true){
        window.location = $(this).attr('href');
        }
    });
});
</script>
<?php
echo $OUTPUT->footer();

die;
