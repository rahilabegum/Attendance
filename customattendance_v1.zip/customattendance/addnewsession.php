<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Local segment_admin addnewsession.
 *
 * @package    local_segment_admin
 * @category   views
 * @copyright 2019 Your Name <your@email.address>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/authlib.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->dirroot . '/mod/customattendance/lib/userfilters.php');
$action = optional_param('action', '', PARAM_TEXT);
$id       = optional_param('mid', '0', PARAM_INT);
$n       = optional_param('n', '0', PARAM_INT);
$sessionid = optional_param('sessionid', '0', PARAM_INT);
require_login();
//$PAGE->set_url('/mod/customattendance/addnewsession.php?mid='.$id."sessionid=".$sessionid);
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->requires->jquery();
$cattendanceid = optional_param('id', 0, PARAM_INT);

$PAGE->set_url('/mod/customattendance/addnewsession.php', array(
    'mid' => $id, 'sessionid' => $sessionid
));

$PAGE->requires->jquery();
$PAGE->requires->jquery_plugin('ui');
$module = array(
    'name' => 'mod_customattendance_addnewsession',
    'fullpath' => '/mod/customattendance/view.js',
    'requires' => array(
        'yui2-dom',
        'yui2-event',
        'yui2-container',
        'yui2-connection',
        'yui2-datatable',
        'yui2-paginator'
    ),
    'strings' => array(),
    'async' => false
);
$PAGE->requires->js_init_call('customattendance_user_datatable_init', null, false, $module);
$cattendanceoutput       = $PAGE->get_renderer('mod_customattendance');
$currenttab       = 'addnewsessions';
$extraeditbuttons = true;
$extrapagetitle   = 'AddNew session';

global $DB;

if ($id) {

    $cm     = get_coursemodule_from_id('customattendance', $id, 0, false, MUST_EXIST);
    $course = $DB->get_record('course', array(
        'id' => $cm->course
    ), '*', MUST_EXIST);
    $cattendance   = $DB->get_record('customattendance', array(
        'id' => $cm->instance
    ), '*', MUST_EXIST);
} else if ($n) {
    $cattendance   = $DB->get_record('customattendance', array(
        'id' => $n
    ), '*', MUST_EXIST);
    $course = $DB->get_record('course', array(
        'id' => $cattendance->course
    ), '*', MUST_EXIST);
    $cm     = get_coursemodule_from_instance('customattendance', $cattendance->att, $course->id, false, MUST_EXIST);
} else {
    error('You must specify a course_module ID or an instance ID');
}
$cattendance->page = '';
$PAGE->set_title(format_string($cattendance->name));
$PAGE->set_heading(format_string($course->fullname));


echo $OUTPUT->header();

require($CFG->dirroot . '/mod/customattendance/tabs.php');


$countrecords = $DB->get_records_sql("SELECT *
									FROM {customattendance_sessions}
									WHERE attendanceid=?", array($cattendanceid));

class sessioncreate_form extends moodleform
{
    public function definition() {
        global $DB;
        $sessionid = optional_param('sessionid', '0', PARAM_INT);
        $sessdetails = $DB->get_record('customattendance_sessions', array('id' => $sessionid));

        global $CFG, $cattendanceid;
        $mform =& $this->_form; // Don't forget the underscore!
        $mform->addElement('hidden', 'id', $sessionid);
        $mform->setType('id', PARAM_INT);
        $mform->addElement('text', 'customattendancename', get_string('sessionname','customattendance'), array(
            'style' => 'width:330px'
        ));
        $mform->addHelpButton('customattendancename', 'sessionname','customattendance');
        $mform->addRule('customattendancename', 'Please Enter Exam Name', 'required', null, 'client');
        $mform->setType('customattendancename', PARAM_TEXT);
        $sname = '';
        if (isset($sessdetails->name))  {
            $sname = $sessdetails->name;
        }
        $mform->setDefault('customattendancename', $sname);

        $startdate = time() + 3600 * 24;
        if (isset($sessdetails->sessdate))  {
            $startdate = $sessdetails->sessdate;
        }
        $enddate = time() + 3600 * 24;
        if (isset($sessdetails->lasttaken))  {
            $enddate = $sessdetails->lasttaken;
        }
        $mform->addElement('date_time_selector', 'startdate', get_string('sessionstarttime','customattendance'));
        $mform->setDefault('startdate', $startdate);
        $mform->addRule('startdate', null, 'required', null, 'client');
        $mform->addHelpButton('startdate', 'startdate','customattendance');
        $mform->addElement('date_time_selector', 'enddate', get_string('sessionendtime','customattendance'));
        $mform->setDefault('enddate', $enddate);
        $mform->addHelpButton('enddate', 'enddate','customattendance');
        $mform->addRule('enddate', null, 'required', null, 'client');
    }
    // Custom validation should be added here.
    public function validation($data, $files) {
        global $DB;
        if (isset($data['cancel'])) {
            redirect(new moodle_url('/mod/customattendance/listsession.php'));
            exit;
        }
        $recordexist = $DB->get_records_sql("select * from {customattendance_sessions}
        where id <> " . $data['id'] . " and name='" . trim($data['customattendancename']) . "'");
        $errors      = parent::validation($data, $files);
        if (!empty($recordexist)) {
            $errors['customattendancename'] = get_string('sessionexits','customattendance');
        }
        if (trim($data['customattendancename']) == '') {
            $errors['customattendancename'] = get_string('customattendancename_help','customattendance');
        }
        if ($data['enddate'] <= $data['startdate']) {
            $errors['enddate'] = get_string('enddategreater','customattendance');
        }
        return $errors;
    }
    public function definition_after_data() {
        parent::definition_after_data();
        global $CFG, $DB, $cattendanceid, $OUTPUT;
        $mform =& $this->_form;

        $this->add_action_buttons(true, 'Submit');
    }
}

$mform = new sessioncreate_form($CFG->wwwroot . "/mod/customattendance/addnewsession.php?mid=$id&sessionid=$sessionid");
if ($mform->is_cancelled()) {
    redirect(new moodle_url('/mod/customattendance/listsession.php'));
} else if ($data = $mform->get_data()) {
    if (isset($data->cancel)) {
        redirect(new moodle_url('/mod/customattendance/listsession.php'));
        exit;
    }
    if ($data) {
        $record               = new stdClass();
        $record->attendanceid     = $cm->instance;
        $record->groupid     = 0;
        $record->name     = $data->customattendancename;
        $record->sessdate    = $data->startdate;
        $record->lasttaken      = $data->enddate;
        $record->lasttakenby = $USER->id;
        $record->description      = "Daily attendance";
        $record->timemodified = time();


        if (!$sessionid) {
            $record->timecreated = time();
            $DB->insert_record('customattendance_sessions', $record);
            redirect(new moodle_url('/mod/customattendance/listsession.php?id='.$cm->id), get_string('sessionadd','customattendance'), 3);
        } else {
            $record->id = $sessionid;
            $DB->update_record('customattendance_sessions', $record);
            redirect(new moodle_url('/mod/customattendance/listsession.php?id='.$cm->id),
            get_string('sessionupdate','customattendance'), 3);
        }
    }
} else {
    $update = $DB->get_record('customattendance_sessions', array(
        'id' => $cattendanceid
    ));
    $mform->set_data($update);

    echo $OUTPUT->heading(($action == 'edit') ?
    get_string('editsession','customattendance') : get_string('addnewsession','customattendance'));
    $mform->display();

}

?>
<script src="js/jquery.validate.min.js"></script>
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 30px;
}
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}
.slider:before {
  position: absolute;
  content: "";
  height: 22px;
  width: 22px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}
input:checked + .slider {
    background-color: green;

<?php
$countrecords = $DB->get_records_sql("SELECT *
									FROM {customattendance_sessions}
								    WHERE exam=?", array($cattendanceid));
if ($cattendanceid && !empty($countrecords)) {
?>
           opacity :0.2;
    <?php
}
?>
   }
input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}
input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}
/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}
.slider.round:before {
  border-radius: 50%;
}
#loader {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: rgba(0,0,0,0.5) url('../../../pix/i/loading.gif') no-repeat center center;
  z-index: 10000;
}
</style>
<script>
$(document).ready(function() {

});
</script>
<div id="loader"></div>
<?php
echo $OUTPUT->footer();