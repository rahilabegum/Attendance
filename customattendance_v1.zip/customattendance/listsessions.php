<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Local segment_admin listexams.
 *
 * @package    local_segment_admin
 * @category   views
 * @copyright  2019 Your Name <your@email.address>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once('../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/authlib.php');
require_once($CFG->dirroot . '/mod/customattendance/lib/userfilters.php');
require_login();
//admin_externalpage_setup('listexams');
$PAGE->set_url('/mod/customattendance/listsession.php');
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->requires->jquery();
$action   = optional_param('action', '', PARAM_TEXT);
$id       = optional_param('id', '0', PARAM_INT);
$page     = optional_param('page', 0, PARAM_INT);
$perpage  = optional_param('perpage', 10, PARAM_INT);
$query    = optional_param('search', '', PARAM_TEXT);
$callback = optional_param('callback', '', PARAM_TEXT);
$url      = new moodle_url('/mod/customattendance/listsession.php');
$PAGE->set_url($url);
if ($page !== 0) {
    $url->param('page', $page);
}
global $DB;
if ($action == 'delete') {
    $DB->delete_records('customattendance_sessions', array(
        'id' => $id
    ));
    redirect(new moodle_url('/mod/customattendance/listsession.php'), get_string('examremove','customattendance'), 3);
}
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('browselistofsession','customattendance'));
if (isset($query) && !empty($query)) {
    $exams         = $DB->get_records_sql("SELECT * FROM {customattendance_sessions} WHERE name
	LIKE '%" . $query . "%' ORDER BY id desc LIMIT " . $perpage . " OFFSET " . ($page * $perpage));
    echo ("SELECT * FROM {customattendance_sessions} WHERE name
	LIKE '%" . $query . "%' ORDER BY id desc LIMIT " . $perpage . " OFFSET " . ($page * $perpage));
    $segmentcount = $DB->get_records_sql("SELECT count(*) as segcount FROM {customattendance_sessions}
	WHERE name LIKE '%" . $query . "%'");
    $countvalues  = (array_keys($segmentcount));
    $sementscount  = $countvalues[0];
    $querystr      = "&search=" . $query;
    echo "test";
} else {
    echo "test1";
    $exams        = $DB->get_records('customattendance_sessions', array(), 'id ASC', '*', ($page * $perpage), $perpage);
    $sementscount = $DB->count_records('customattendance_sessions', array());
    $querystr     = "";
}
// Add filters.
$table                      = new html_table();
$table->head                = array();
$table->colclasses          = array();
$table->attributes['class'] = 'admintable generaltable';
$table->head[]              = get_string('customattendancename','customattendance');
$table->head[]              = get_string('startdate','customattendance');
$table->head[]              = get_string('enddate','customattendance');
$table->head[]              = get_string('status','customattendance');
$table->head[]              = get_string('action','customattendance');
$table->colclasses[]        = 'centeralign';
$table->id                  = "exams";
echo html_writer::start_tag('div', array(
    'class' => 'no-overflow'
));
foreach ($exams as $key => $exam) {
    $buttons   = array();
    $buttons[] = html_writer::link(new moodle_url($CFG->wwwroot . '/mod/customattendance/addnewsession.php?action=edit', array(
        'id' => $exam->id
    )), html_writer::empty_tag('img', array(
        'src' => $OUTPUT->image_url('t/edit'),
        'alt' => '',
        'class' => 'iconsmall'
    )), array(
        'title' => ''
    ));
    $row           = array();
    $row[]         = $exam->name;
    $row[]         = userdate($exams[$exam->id]->sessdate);
    $row[]         = userdate($exams[$exam->id]->lasttaken);
    $row[]         = $exam->activateexam == 1 ? 'Active' : 'Inactive';
    $row[]         = implode(' ', $buttons);
    $table->data[] = $row;
}
?>
<div style="text-align:right;">
<input type="button" value="Create exam" onclick="window.location.href='addnewsession.php'">
</div>
<?php
// Add search form.
$search = html_writer::start_tag('form', array(
    'id' => 'searchcohortquery',
    'method' => 'get'
));
$search .= html_writer::start_tag('div');
$search .= html_writer::label('Search exam', 'cohort_search_q'); // No : in form labels!
$search .= html_writer::empty_tag('input', array(
    'id' => 'cohort_search_q',
    'type' => 'text',
    'name' => 'search',
    'value' => $query
));
$search .= html_writer::empty_tag('input', array(
    'type' => 'submit',
    'value' => get_string('search', 'cohort')
));
$search .= html_writer::end_tag('div');
$search .= html_writer::end_tag('form');
echo $search;
$pagingbar = new paging_bar($sementscount, $page, $perpage, $url . '?perpage=' . $perpage . $querystr);
echo '<div class="" style="margin:0;">' . $OUTPUT->render($pagingbar) . '</div>';
echo html_writer::table($table);
echo '<div class="" style="margin:0;">' . $OUTPUT->render($pagingbar) . '</div>';
echo html_writer::end_tag('div');
?>
<script>
$(document).ready(function() {
    $('.deleteid').click(function(event) {
    event.preventDefault();
    var r=confirm("Are you sure want to delete?");
        if (r==true){
        window.location = $(this).attr('href');
        }
    });
});
</script>
<?php
echo $OUTPUT->footer();
