<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * English strings for exam
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_exam
 * @copyright  2015 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
/* used */
$string['modulename'] = 'C-attendance';
$string['modulenameplural'] = 'Custom Attendance';
$string['exam'] = 'Custom Attendance';
$string['pluginname'] = 'Custom Attendance';
$string['customattendancename'] = 'Attendance name';
$string['sessionname'] = 'Session name';
$string['sessiondate'] = "Date";
$string['sessionstarttime'] = 'Start-Time';
$string['sessionendtime'] = 'End-Time';
$string['addnewsession'] = "Add New Session";
$string['enddategreater'] = 'End Date should be greater than Start Date';
$string['sessionupdate'] = 'Session updated successfully';
$string['sessionadd'] = 'Session added successfully';
$string['browselistofsession'] = 'Session List';
$string['attendanceadd'] = 'Attendance taken successfully';
$string['myattendance'] = '<h2>My Attendance</h2>';
$string['sessionname_help'] = "Add session name";
$string['customattendancename_help'] = "Add session name";
$string['startdate'] = "Select session start date and time";
$string['startdate_help'] = "Select session start date and time";
$string['enddate'] = "Select session end date and time";
$string['enddate_help'] = "Select session end date and time";
$string['editsession'] = "Edit Session";
$string['sessionexits'] = "Session name already Exits";
$string['action'] = "Action";

/* */

$string['modulename_help'] = 'Use the exam module for... | The exam module allows...';
$string['pluginadministration'] = 'Exam administration';

